package com.example.act22.ui.theme

import androidx.compose.ui.graphics.Color

val NewWhite = Color(0xFFD9D9D9)
val NewDark = Color(0xFF22172B)
val NewPurple = Color(0xFF510D7A)

val SupportWhite = Color(0xFFAFAFAF)
val SupportBlue = Color(0xFF193C95)

