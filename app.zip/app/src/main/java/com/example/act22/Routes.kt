package com.example.act22

val StartPage = "Start_Page"
val SingInPage = "SignIn_Page"
val SingUpPage = "SignUp_Page"
val MainPage = "Main_Page"